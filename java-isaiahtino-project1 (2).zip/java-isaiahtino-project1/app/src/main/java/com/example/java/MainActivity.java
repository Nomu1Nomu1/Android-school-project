package com.example.java;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    int count = 0;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView= findViewById(R.id.text);
    }

    public void showToast(View view) {
        textView.setText("0");
        Toast.makeText(this, "Successfully reset", Toast.LENGTH_SHORT).show();
    }

    public void countUp(View view) {
        count++;
        textView.setText(count + "");
    }

    public void countDown(View view) {
        count--;
        textView.setText(count + "");
    }

    public void switchActivity(View view) {
        Intent intent = new Intent(this, secondActivity.class);
        startActivity(intent);
    }
}
package com.example.java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;


public class secondActivity extends AppCompatActivity {

    EditText PhoneNum;
    RadioButton radioMobile, radioRumah, radioKantor;
    Button Submit;

    String urNumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        PhoneNum = (EditText) findViewById(R.id.Phone);
        radioMobile = (RadioButton) findViewById(R.id.rMobile);
        radioRumah = (RadioButton) findViewById(R.id.rRumah);
        radioKantor = (RadioButton) findViewById(R.id.rKantor);
        Submit =(Button)findViewById(R.id.submit);
        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nophone = PhoneNum.getText().toString();
                if (radioMobile.isChecked()){
                    urNumber = radioMobile.getText().toString();
                }else if (radioRumah.isChecked()){
                    urNumber = radioRumah.getText().toString();
                }else if (radioKantor.isChecked()){
                    urNumber = radioKantor.getText().toString();
                }
                Toast.makeText(getApplicationContext(), urNumber + " " + nophone, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void back(View view) {
        finish();
    }
}